using System.Collections;
using System.Text;

namespace Tp_balino
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Random rand;
        string[] words = {
            "Guess",
            "Apple",
            "Club Classics",
            "Von dutch",
            "Spring breakers",
            "360",
            "365",
            "So I",
            "B2b ",
            "Mean girls",
            "Talk talk",

        };
        string word;
        int word_order;

        public void load_word()
        {
            if (word_order < words.Length)
            {
                word = words[word_order].ToUpper();

                int word_Length = word.Length;

                StringBuilder maskedWord = new StringBuilder(word_Length);

                int masks = word_Length / 2;

                ArrayList letter_masks = new ArrayList();

                for (int i = 0; i < masks; i++)
                {
                    bool can_loop = true;
                    do
                    {
                        int rand_num = rand.Next(word_Length);
                        if (!letter_masks.Contains(rand_num))
                        {
                            letter_masks.Add(rand_num);
                            can_loop = false;
                        }
                    } while (can_loop);
                }
                for (int i = 0; i < word_Length; i++)
                {
                    if (letter_masks.Contains(i))
                    {
                        maskedWord.Append("?");
                    }
                    else
                    {
                        maskedWord.Append(word[i]);
                    }

                }

                lb_mask_word.Text = maskedWord.ToString();
            }
            else
            {
                refresh_word();
                load_word();
            }
        }

        public void refresh_word()
        {
            words = words.OrderBy(x => rand.Next()).ToArray();

            word_order = 0;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            rand = new Random();

            refresh_word();
            load_word();
        }

        private void tb_guess_Click(object sender, EventArgs e)
        {
            if (tb_guess.Text.Equals("One more?"))
            {
                word_order++;
                load_word();
                tb_guess.Text = "Guess";
                wrong_guess_list.Items.Clear();
            }
            if (!tb_answer.Text.Equals(""))
            {
                if (tb_answer.Text.ToUpper().Equals(word))
                {
                    lb_mask_word.Text = word;
                    tb_guess.Text = "One more?";
                    MessageBox.Show("Correct Guess");
                }
                else
                {
                    wrong_guess_list.Items.Add(tb_answer.Text);

                    MessageBox.Show("Woop Woop");
                }
                tb_answer.Text = "";
            }
        }
    }
}
